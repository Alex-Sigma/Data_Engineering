import smtplib
from email.mime.text import MIMEText

msg = MIMEText("Тестовое сообщение из Airflow.")
msg["Subject"] = "SMTP test from Brevo"
msg["From"] = "alex3astakhov@gmail.com"
msg["To"] = "alex3astakhov@gmail.com"

with smtplib.SMTP("smtp-relay.brevo.com", 587) as server:
    server.starttls()
    server.login("903051001@smtp-brevo.com", "xsmtpsib-11cd1f1ec7c8649de630172dfc3cb7faaa3fc5f990ac88fd7f802f405fa5f177-aDKfV2YwcMSXAJgz")  # замените на свой ключ
    server.send_message(msg)

print("✅ Email отправлен")
